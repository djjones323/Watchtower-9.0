package com.watchtower.osint

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.os.Build
import java.util.concurrent.Executors

class RefreshJobService : JobService() {
    private val executor=Executors.newSingleThreadExecutor()
    override fun onStartJob(params:JobParameters):Boolean {
        executor.execute {
            try {
                val old=SignalStore.load(this)
                val ids=old.map{it.id}.toSet()
                val fresh=FeedEngine.fetchAll().signals.filter{it.id !in ids}
                val merged=(fresh+old).distinctBy{it.id}.sortedByDescending{it.date}.take(600)
                SignalStore.save(this,merged)
                fresh.filter{it.official&&it.score()>=7}.forEach{notifySignal(it)}
            } catch (_:Exception) { }
            jobFinished(params,false)
        }
        return true
    }
    override fun onStopJob(params:JobParameters):Boolean=true
    private fun notifySignal(s:Signal){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel("watchtower_alerts","Watchtower high-priority signals",NotificationManager.IMPORTANCE_DEFAULT))
        val pi=PendingIntent.getActivity(this,s.id.hashCode(),Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b=if(Build.VERSION.SDK_INT>=26)android.app.Notification.Builder(this,"watchtower_alerts") else android.app.Notification.Builder(this)
        nm.notify(s.id.hashCode(),b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("WATCHTOWER · ${s.score()}/10").setContentText(s.title).setContentIntent(pi).setAutoCancel(true).build())
    }
}
