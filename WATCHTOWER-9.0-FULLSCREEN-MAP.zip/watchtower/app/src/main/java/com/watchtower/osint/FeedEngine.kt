package com.watchtower.osint

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID

 data class FeedSource(val name:String,val url:String,val category:String,val official:Boolean,val region:String="International")
data class FeedBatch(val signals:List<Signal>,val successful:Int,val failed:Int,val failedSources:List<String> = emptyList())

object FeedEngine {
    // Official feeds are prioritized. Google News RSS is discovery-only and never treated as primary evidence.
    val sources = listOf(
        FeedSource("CISA Cybersecurity Advisories","https://www.cisa.gov/cybersecurity-advisories/all.xml","Communications",true,"United States"),
        FeedSource("CISA News","https://www.cisa.gov/news-events/news.xml","Energy infrastructure",true,"United States"),
        FeedSource("Federal Reserve Press Releases","https://www.federalreserve.gov/feeds/press_all.xml","Financial signals",true,"United States"),
        FeedSource("FEMA News Releases","https://www.fema.gov/news-releases.xml","Civil defence",true,"United States"),
        FeedSource("NATO News","https://www.nato.int/cps/en/natohq/news_rss.xml","Civil defence",true,"International"),
        FeedSource("Federal Register: emergency preparedness","https://www.federalregister.gov/documents/search.atom?conditions%5Bterm%5D=emergency%20preparedness","Government procurement",true,"United States"),
        FeedSource("News discovery: embassy alerts","https://news.google.com/rss/search?q=embassy+security+alert+evacuation&hl=en-US&gl=US&ceid=US:en","Embassy activity",false),
        FeedSource("News discovery: military aviation","https://news.google.com/rss/search?q=military+airlift+tanker+airspace+restriction&hl=en-US&gl=US&ceid=US:en","Flight activity",false),
        FeedSource("News discovery: maritime cables","https://news.google.com/rss/search?q=undersea+cable+damage+maritime+warning&hl=en-US&gl=US&ceid=US:en","Maritime activity",false),
        FeedSource("News discovery: power grid","https://news.google.com/rss/search?q=power+grid+transformer+emergency+procurement&hl=en-US&gl=US&ceid=US:en","Energy infrastructure",false),
        FeedSource("News discovery: satellite interference","https://news.google.com/rss/search?q=GNSS+GPS+spoofing+jamming+warning&hl=en-US&gl=US&ceid=US:en","Communications",false),
        FeedSource("News discovery: government procurement","https://news.google.com/rss/search?q=government+emergency+generator+fuel+procurement&hl=en-US&gl=US&ceid=US:en","Government procurement",false),
        FeedSource("News discovery: civil defence","https://news.google.com/rss/search?q=civil+defence+stockpile+emergency+preparedness&hl=en-US&gl=US&ceid=US:en","Civil defence",false),
        FeedSource("News discovery: financial stability","https://news.google.com/rss/search?q=central+bank+emergency+liquidity+financial+stability&hl=en-US&gl=US&ceid=US:en","Financial signals",false),
        FeedSource("News discovery: restaurant activity","https://news.google.com/rss/search?q=Pentagon+pizza+activity+Washington+DC&hl=en-US&gl=US&ceid=US:en","Restaurant activity",false)
    )

    fun fetchAll(): FeedBatch {
        val found = mutableListOf<Signal>()
        var successful = 0
        var failed = 0
        val failedNames = mutableListOf<String>()
        sources.forEach { source ->
            try { found += fetch(source); successful++ } catch (_: Exception) { failed++; failedNames += source.name }
        }
        return FeedBatch(found, successful, failed, failedNames)
    }

    private fun fetch(source: FeedSource): List<Signal> {
        val connection = URL(source.url).openConnection() as HttpURLConnection
        connection.connectTimeout = 9000; connection.readTimeout = 12000
        connection.setRequestProperty("User-Agent","WATCHTOWER-OSINT/1.0 (public feed reader)")
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
            val parser = Xml.newPullParser(); parser.setInput(connection.inputStream,"UTF-8")
            val result = mutableListOf<Signal>()
            var event = parser.eventType
            var inItem = false; var title=""; var link=""; var description=""; var date=""
            while (event != XmlPullParser.END_DOCUMENT) {
                when(event) {
                    XmlPullParser.START_TAG -> {
                        val tag=parser.name.lowercase(Locale.US)
                        if (tag=="item" || tag=="entry") { inItem=true; title="";link="";description="";date="" }
                        else if(inItem) when(tag) {
                            "title" -> title=parser.nextTextSafe()
                            "link" -> { link=parser.getAttributeValue(null,"href") ?: parser.nextTextSafe() }
                            "description","summary","content" -> description=parser.nextTextSafe()
                            "pubdate","published","updated" -> date=parser.nextTextSafe()
                        }
                    }
                    XmlPullParser.END_TAG -> if(parser.name.equals("item",true)||parser.name.equals("entry",true)) {
                        inItem=false
                        if(title.isNotBlank() && link.isNotBlank()) {
                            val official=source.official
                            val reliability=if(official) 5 else 2
                            val clean=description.replace(Regex("<[^>]*>")," ").replace(Regex("\\s+")," ").take(650)
                            val lower=(title+" "+clean).lowercase(Locale.US)
                            val urgentWords=listOf("evacuat","emergency order","immediate danger","attack underway","shelter in place","critical outage")
                            val unusualWords=listOf("sabotage","cable damage","grid attack","mass outage","jamming","spoofing","emergency declaration")
                            val immediate=official && listOf("evacuate now","shelter in place","effective immediately","immediate danger","emergency order").any{lower.contains(it)}
                            val urgency=if(immediate) 5 else if(official && unusualWords.any{lower.contains(it)}) 4 else 1
                            val novelty=if(unusualWords.any{lower.contains(it)}) 3 else 2
                            val impact=if(official && (urgency>=4 || unusualWords.any{lower.contains(it)})) 4 else 2
                            val timing=when {
                                immediate -> "Immediate official warning"
                                lower.contains("within 7 days") -> "Expected within 7 days"
                                lower.contains("within 30 days") -> "Expected within 30 days"
                                lower.contains("ongoing") -> "Ongoing"
                                else -> "Not stated"
                            }
                            result += Signal(UUID.nameUUIDFromBytes(link.toByteArray()).toString(),title.take(240),source.category,
                                source.region,source.name,link,clean,parseDate(date),reliability,1,novelty,urgency,impact,official,timing,false)
                        }
                    }
                }
                event=parser.next()
            }
            return result.take(30)
        } finally { connection.disconnect() }
    }

    private fun XmlPullParser.nextTextSafe(): String = try { nextText() } catch (_: Exception) { "" }

    private fun parseDate(value:String):Long {
        if(value.isBlank()) return System.currentTimeMillis()
        val formats=listOf("EEE, dd MMM yyyy HH:mm:ss Z","yyyy-MM-dd'T'HH:mm:ss'Z'","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd")
        for(pattern in formats) try { return java.text.SimpleDateFormat(pattern,Locale.US).parse(value)?.time ?: continue } catch (_:Exception) { }
        return System.currentTimeMillis()
    }

}
