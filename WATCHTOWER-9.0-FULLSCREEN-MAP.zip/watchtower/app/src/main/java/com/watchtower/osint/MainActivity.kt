package com.watchtower.osint

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.text.Html
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var mapView: WebView? = null
    private var hotspotDetail: TextView? = null
    private var selectedCategory = "All categories"
    private var signals = mutableListOf<Signal>()
    private var pizzaStatus = "Free venue lookup not yet run. No free public source provides reliable live restaurant footfall."
    private val bg = Color.rgb(16,21,27)
    private val panel = Color.rgb(26,34,44)
    private val muted = Color.rgb(154,168,183)
    private val green = Color.rgb(84,214,160)
    private val blue = Color.rgb(121,185,245)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=bg
        signals=SignalStore.load(this)
        createNotificationChannel()
        requestNotificationPermission()
        scheduleRefresh()
        buildUi()
        refreshFeeds(false)
    }

    private fun buildUi() {
        val scroll=ScrollView(this)
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(28)); setBackgroundColor(bg) }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(text("WATCHTOWER",25,Color.WHITE,true).apply { maxLines = 1; includeFontPadding = true })
        root.addView(text("OPEN-SOURCE INTELLIGENCE  ·  CIVILIAN RESILIENCE",10,muted,false).apply { letterSpacing=.12f })
        root.addView(space(10))
        root.addView(text("GLOBAL ACTIVITY MAP  ·  72H",12,blue,true))
        root.addView(text("GEOSPATIAL ANOMALY MONITOR  /  PUBLIC-SOURCE INTELLIGENCE",9,muted,false))
        val mapFrame=FrameLayout(this).apply {
            tag = "global_map_frame"
            setBackgroundColor(Color.rgb(3,8,15))
            layoutParams=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(430))
        }
        val map=WebView(this).apply {
            setBackgroundColor(Color.rgb(3,8,15))
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.loadWithOverviewMode=true
            settings.useWideViewPort=true
            isVerticalScrollBarEnabled=false
            isHorizontalScrollBarEnabled=false
        }
        mapView=map
        mapFrame.addView(map,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(mapFrame)
        renderGlobalMap()
        root.addView(space(8))
        hotspotDetail=text("Select a highlighted region to inspect its contributing public records.",11,Color.LTGRAY,false)
        root.addView(hotspotDetail)
        root.addView(space(12))
        val stats=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val count=signals.size
        val high=signals.count{it.score()>=7}
        stats.addView(statCard("SIGNALS",count.toString()),LinearLayout.LayoutParams(0,dp(82),1f))
        stats.addView(spaceW(8))
        stats.addView(statCard("PRIORITY ≥7",high.toString()),LinearLayout.LayoutParams(0,dp(82),1f))
        stats.addView(spaceW(8))
        stats.addView(statCard("CATEGORIES",signals.map{it.category}.distinct().size.toString()+"/9"),LinearLayout.LayoutParams(0,dp(82),1f))
        root.addView(stats)
        root.addView(space(12))
        root.addView(space(16))
        val buttons=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        buttons.addView(button("↻ Refresh",green){refreshFeeds(true)},LinearLayout.LayoutParams(0,dp(46),1f))
        buttons.addView(spaceW(8))
        buttons.addView(button("+ Add signal",blue){showAddDialog()},LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(buttons)
        root.addView(space(8))
        root.addView(button("🔐 Provider access & sign-in", blue) {
            startActivity(Intent(this, ProviderAccessActivity::class.java))
        })
        renderFieldNotes()
        root.addView(space(10))
        status=text("Starting public-source checks…",12,muted,false)
        root.addView(status); root.addView(space(12))
        root.addView(text("MONITORING CATEGORIES",12,muted,true))
        val spinner=Spinner(this)
        val options=listOf("All categories","Watchlist matches")+Categories.all
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,options)
        spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?) {}
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){selectedCategory=options[position];renderSignals()}
        }
        root.addView(spinner)
        root.addView(space(12))
        root.addView(text("LATEST PUBLIC SIGNALS",12,muted,true))
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(space(16))
        root.addView(text("SCORING MODEL",12,muted,true))
        root.addView(text("Source reliability 30% · Independent corroboration 25% · Unusualness 20% · Time sensitivity 15% · Potential public impact 10%",12,Color.LTGRAY,false))
        root.addView(space(8))
        root.addView(text("Evidence priority (1–10) ranks the strength of the record. Source-stated imminence (1–10) reflects only the timing explicitly stated by the source; it is NOT a probability that an event will happen. Similar headlines are not proof of a common cause. News-search feeds are discovery sources, not primary evidence.",11,muted,false))
        root.addView(space(12))
        root.addView(button("Export history (JSON)",blue){exportHistory()})
        renderSignals()
    }

    private fun renderGlobalMap() {
        val view = mapView ?: return
        val hotspots = AnomalyEngine.analyze(signals)
        val array = org.json.JSONArray()
        hotspots.forEach { h ->
            array.put(org.json.JSONObject()
                .put("region", h.region).put("lat", h.latitude).put("lon", h.longitude)
                .put("score", h.score).put("count", h.signalCount)
                .put("categories", h.categories.joinToString(" · "))
                .put("publishers", h.publishers).put("explanation", h.explanation))
        }
        val html = """
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
*{box-sizing:border-box}html,body,#map{height:100%;width:100%;margin:0;background:#030812;font-family:Arial,sans-serif;overflow:hidden}
.leaflet-tile-pane{filter:invert(1) hue-rotate(180deg) brightness(.72) contrast(1.12)}
.leaflet-container{background:#030812}.leaflet-control-attribution{background:rgba(2,8,16,.72)!important;color:#8297aa!important;font-size:8px!important}
.leaflet-control-attribution a{color:#7ddcff!important}
.hud{position:absolute;z-index:900;background:rgba(4,13,26,.88);border:1px solid rgba(0,211,255,.42);box-shadow:0 0 18px rgba(0,180,255,.12);color:#e8f7ff}
.brand{top:10px;left:10px;padding:8px 11px;letter-spacing:2px;font-size:12px;font-weight:bold;border-left:3px solid #00d9ff}
.brand small{display:block;color:#78a9c3;font-size:8px;letter-spacing:1px;margin-top:4px;font-weight:normal}
.status{top:10px;right:10px;padding:7px 9px;font-size:8px;color:#6fffc1;letter-spacing:1px}
.left{left:10px;top:72px;width:132px;max-height:48%;overflow:auto;padding:8px}
.paneltitle{font-size:8px;color:#00d9ff;letter-spacing:1.5px;margin-bottom:7px}
.hot{padding:6px 3px;border-bottom:1px solid rgba(100,170,200,.16);font-size:9px;cursor:pointer}
.hot b{float:right;color:#ff806a}.hot span{display:block;color:#7898ad;font-size:8px;margin-top:3px}
.bottom{left:10px;right:10px;bottom:12px;padding:8px 10px;min-height:50px}
.bottom strong{font-size:10px;color:#00d9ff;letter-spacing:1px}.bottom div{font-size:9px;color:#c2d4df;margin-top:4px;line-height:1.35}
.legend{right:10px;bottom:90px;padding:7px 9px;font-size:8px;line-height:1.8}
.dot{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px}
.arc{position:absolute;z-index:400;pointer-events:none;left:-20%;width:140%;height:75px;bottom:-42px;border-top:2px solid rgba(0,213,255,.65);border-radius:50% 50% 0 0;box-shadow:0 -8px 25px rgba(0,168,255,.22)}
.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#081727;color:#e8f7ff;border:1px solid #087b9c}
.leaflet-popup-content{font-size:11px;line-height:1.45}
@media(max-width:380px){.left{width:112px}.brand{font-size:10px}.status{font-size:7px}}
</style></head><body>
<div id="map"></div>
<div class="hud brand">WATCHTOWER <small>GLOBAL ANOMALY FIELD · 72H</small></div>
<div class="hud status">● PUBLIC DATA FEEDS</div>
<div class="hud left"><div class="paneltitle">REGIONAL HOTSPOTS</div><div id="hotlist"></div></div>
<div class="hud legend"><span class="dot" style="background:#ff3d55"></span>HIGH<br><span class="dot" style="background:#ff9b39"></span>ELEVATED<br><span class="dot" style="background:#a65cff"></span>WATCH</div>
<div class="hud bottom"><strong id="selected">GLOBAL VIEW · SELECT A HOTSPOT</strong><div id="detail">Heat zones show clustered public-source records. They are activity anomalies, not threat probabilities.</div></div>
<div class="arc"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const items=__DATA__;
const map=L.map('map',{worldCopyJump:true,zoomControl:false,scrollWheelZoom:true,minZoom:2,maxZoom:7}).setView([22,8],2);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{subdomains:'abcd',maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
L.control.zoom({position:'bottomright'}).addTo(map);
function color(v){return v>=8?'#ff3d55':v>=5?'#ff9b39':'#a65cff'}
function select(h){
 document.getElementById('selected').textContent=h.region.toUpperCase()+' · ANOMALY INDEX '+h.score+'/10';
 document.getElementById('detail').textContent=h.count+' records · '+h.categories+' · '+h.publishers+' publishers. '+h.explanation+' Relative activity only; not a threat probability.';
}
const list=document.getElementById('hotlist');
if(!items.length){list.innerHTML='<div class="hot">No qualified hotspots yet<span>Insufficient geographically tagged records</span></div>';}
items.forEach(h=>{
 const c=color(h.score);
 L.circle([h.lat,h.lon],{radius:220000+ h.score*85000,color:c,weight:1,opacity:.45,fillColor:c,fillOpacity:.17}).addTo(map);
 const marker=L.circleMarker([h.lat,h.lon],{radius:5+h.score*1.05,color:'#eafaff',weight:1,fillColor:c,fillOpacity:.95}).addTo(map);
 marker.bindPopup('<b>'+h.region+'</b><br>Index '+h.score+'/10<br>'+h.count+' records · '+h.publishers+' publishers');
 marker.on('click',()=>select(h));
 const row=document.createElement('div');row.className='hot';row.innerHTML=h.region+' <b>'+h.score+'/10</b><span>'+h.count+' records · '+h.categories.split(' · ').slice(0,2).join(', ')+'</span>';
 row.onclick=()=>{map.setView([h.lat,h.lon],Math.max(4,map.getZoom()));marker.openPopup();select(h)};
 list.appendChild(row);
});
if(items.length){const top=items[0];select(top);}
</script></body></html>
        """.trimIndent().replace("__DATA__", array.toString())
        view.loadDataWithBaseURL("https://unpkg.com/", html, "text/html", "UTF-8", null)
    }

    private fun renderFieldNotes() {
        if (!::root.isInitialized) return
        val cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000
        val recent = signals.filter { it.date >= cutoff }
        val dcPizzaItems = recent.filter {
            it.category == "Restaurant activity" &&
            (it.region.contains("Washington", true) || it.region.contains("United States", true) ||
             (it.title + " " + it.summary).contains("Washington", true) ||
             (it.title + " " + it.summary).contains("Pentagon", true) ||
             (it.title + " " + it.summary).contains("DC", true))
        }
        val pizzaMentions = dcPizzaItems.size
        val watchWords = SignalStore.loadWatchlist(this)
        val watchHits = recent.filter { signal ->
            watchWords.any { word -> (signal.title + " " + signal.summary).contains(word, ignoreCase = true) }
        }
        val clusters = candidateClusters(recent)
        val categoryCounts = recent.groupingBy { it.category }.eachCount().entries.sortedByDescending { it.value }
        val history = SignalStore.loadRefreshHistory(this)
        val trend = if (history.length() >= 2) {
            val previous = history.getJSONObject(history.length() - 2).optInt("items")
            val latest = history.getJSONObject(history.length() - 1).optInt("items")
            if (latest > previous) "↑ ${latest - previous} items since previous refresh"
            else if (latest < previous) "↓ ${previous - latest} items since previous refresh"
            else "No change since previous refresh"
        } else "Trend begins after another refresh"
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
        }
        card.addView(text("WATCHTOWER INTELLIGENCE DESK · EXPERIMENTAL", 11, muted, true))
        card.addView(text("WATCHLIST: ${watchHits.size} matching items in the last 24h", 15, if (watchHits.isEmpty()) Color.WHITE else Color.rgb(243,189,96), true))
        card.addView(text(if (watchHits.isEmpty()) "No current keyword matches. This is not an all-clear." else watchHits.take(3).joinToString("  •  ") { it.title.take(65) }, 11, muted, false))
        card.addView(button("Manage watchlist keywords", blue) { showWatchlistDialog() })
        card.addView(text("EVENT CLUSTERS: ${clusters.size} candidate groups", 14, Color.WHITE, true))
        card.addView(text("Groups use title similarity and publisher diversity to find items worth reviewing. They are leads, not verified corroboration.", 10, muted, false))
        card.addView(text("ACTIVITY VOLUME · LAST 24H", 12, blue, true))
        val categoryLine = if (categoryCounts.isEmpty()) "No recent items" else categoryCounts.take(4).joinToString("  ·  ") { "${it.key.substringBefore(' ')} ${it.value}" }
        card.addView(text(categoryLine, 11, Color.LTGRAY, false))
        card.addView(text("PENTAGON-AREA PIZZA TRAFFIC · EXPERIMENTAL", 12, Color.rgb(243,189,96), true))
        card.addView(text(pizzaStatus, 11, Color.LTGRAY, false))
        card.addView(button("↻ Find pizza venues using free OpenStreetMap data", Color.rgb(243,189,96)) { refreshPizzaTraffic() })
        card.addView(button("＋ Record Google Maps Popular Times observation", blue) { showPizzaObservationDialog() })
        card.addView(button("Open Pentagon-area pizza places in Google Maps", blue) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/pizza+near+the+Pentagon+Arlington+VA")))
        })
        card.addView(text("FREE MODE · OpenStreetMap supplies real venue locations, not visitor counts. Google Maps traffic observations are entered manually. No paid traffic API, no fabricated live score, and no subscription.", 10, muted, false))
        val venueSnap = FreePizzaEngine.load(this)
        if (venueSnap != null) card.addView(text("OSM directory: ${venueSnap.venuesFound} named venues found · fetched ${date(venueSnap.fetchedAt)}", 10, muted, false))
        val observation = FreePizzaEngine.latestManualObservation(this)
        if (observation != null) card.addView(text("LAST MANUAL OBSERVATION: ${observation.optInt("score")}/10 · ${date(observation.optLong("time"))} · ${observation.optString("note")}", 10, Color.rgb(243,189,96), false))
        card.addView(text("Refresh trend: $trend", 11, muted, false))
        val existing = root.findViewWithTag<View>("field_notes")
        if (existing != null) root.removeView(existing)
        card.tag = "field_notes"
        val mapIndex = root.indexOfChild(root.findViewWithTag<View>("global_map_frame"))
        root.addView(card, if (mapIndex >= 0) mapIndex + 1 else root.childCount)
    }

    private fun refreshPizzaTraffic() {
        pizzaStatus = "Looking up public venue locations from OpenStreetMap…"
        renderFieldNotes()
        executor.execute {
            try {
                val result = FreePizzaEngine.fetch(this)
                pizzaStatus = "OSM DIRECTORY · ${result.venuesFound} named venues found · ${result.names.take(5).joinToString(", ")}"
            } catch (e: Exception) {
                pizzaStatus = "VENUE LOOKUP UNAVAILABLE · ${e.message ?: "Try again later"}"
            }
            runOnUiThread { renderFieldNotes() }
        }
    }

    private fun showPizzaObservationDialog() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        wrap.addView(text("Open Google Maps for a pizza restaurant near the Pentagon. Use its Popular Times / live busyness display as your reference, then record what you actually see. This is a manual observation, not an API reading.", 12, muted, false))
        val score = SeekBar(this).apply { max = 9; progress = 4 }
        val value = text("Observed busyness: 5/10", 16, Color.rgb(243,189,96), true)
        score.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                value.text = "Observed busyness: ${progress + 1}/10"
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        val note = EditText(this).apply {
            hint = "Venue name, time, and what Google Maps showed"
            setTextColor(Color.WHITE); setHintTextColor(muted)
        }
        wrap.addView(value); wrap.addView(score); wrap.addView(note)
        AlertDialog.Builder(this).setTitle("Record DC Pizza observation")
            .setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save observation") { _, _ ->
                FreePizzaEngine.saveManualObservation(this, score.progress + 1, note.text.toString())
                pizzaStatus = "Manual Google Maps observation saved."
                renderFieldNotes()
            }.show()
    }

    private fun candidateClusters(items: List<Signal>): List<List<Signal>> {
        val remaining = items.toMutableList()
        val groups = mutableListOf<List<Signal>>()
        fun tokens(s: Signal) = s.title.lowercase(Locale.US)
            .replace(Regex("[^a-z0-9 ]"), " ").split(Regex("\\s+"))
            .filter { it.length > 3 && it !in setOf("with","from","that","this","after","over","into","says","will","have","more","than") }.toSet()
        while (remaining.isNotEmpty()) {
            val seed = remaining.removeAt(0)
            val a = tokens(seed)
            val group = mutableListOf(seed)
            val iterator = remaining.iterator()
            while (iterator.hasNext()) {
                val candidate = iterator.next()
                val b = tokens(candidate)
                val union = (a + b).size
                val similarity = if (union == 0) 0.0 else a.intersect(b).size.toDouble() / union
                if (similarity >= 0.38) { group.add(candidate); iterator.remove() }
            }
            if (group.size >= 2 && group.map { it.publisher }.distinct().size >= 2) groups.add(group)
        }
        return groups.sortedByDescending { it.size }
    }

    private fun showWatchlistDialog() {
        val editor = EditText(this).apply {
            setText(SignalStore.loadWatchlist(this@MainActivity).joinToString("\n"))
            setTextColor(Color.WHITE); setHintTextColor(muted); minLines = 6
            hint = "One keyword or phrase per line"
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
            addView(text("Track phrases in titles and summaries. Matches are review prompts, not threat alerts.", 12, muted, false))
            addView(editor)
        }
        AlertDialog.Builder(this).setTitle("WATCHTOWER watchlist")
            .setView(wrap).setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                SignalStore.saveWatchlist(this, editor.text.toString().lines())
                renderFieldNotes(); renderSignals()
            }.show()
    }

    private fun cleanHtml(value: String): String {
        return if (Build.VERSION.SDK_INT >= 24) {
            Html.fromHtml(value, Html.FROM_HTML_MODE_COMPACT).toString().replace(Regex("\\s+"), " ").trim()
        } else {
            @Suppress("DEPRECATION")
            Html.fromHtml(value).toString().replace(Regex("\\s+"), " ").trim()
        }
    }

    private fun renderSignals() {
        if(!::list.isInitialized)return
        list.removeAllViews()
        val watchWords = SignalStore.loadWatchlist(this).map { it.lowercase(Locale.US) }
        val visible=signals.filter {
            selectedCategory=="All categories" ||
            (selectedCategory=="Watchlist matches" && watchWords.any { word -> (it.title+" "+it.summary).lowercase(Locale.US).contains(word) }) ||
            it.category==selectedCategory
        }.sortedByDescending{it.date}.take(100)
        if(visible.isEmpty()) list.addView(text("No signals in this category yet. Refresh or add a record.",13,muted,false))
        visible.forEach { s ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(13),dp(14),dp(13)); setBackgroundColor(panel) }
            val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val title=text(s.title,15,Color.WHITE,true); title.layoutParams=LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f)
            val score=text("${s.score()}/10",21,scoreColor(s.score()),true)
            top.addView(title);top.addView(score);card.addView(top)
            card.addView(text("${s.category}  ·  ${s.region}",11,blue,false))
            if(s.summary.isNotBlank())card.addView(text(cleanHtml(s.summary),12,Color.LTGRAY,false).apply{setPadding(0,dp(7),0,dp(5))})
            card.addView(text("${s.publisher}  ·  ${if(s.official)"Official feed" else "Discovery feed"}  ·  ${date(s.date)}",10,muted,false))
            card.addView(text("Evidence priority ${s.score()}/10 · Source-stated imminence ${s.imminenceScore()}/10",11,blue,true))
            card.addView(text("Reliability ${s.sourceReliability}/5 · Corroboration ${s.corroboration}/5 · Unusualness ${s.unusualness}/5 · Urgency ${s.urgency}/5 · Impact ${s.impact}/5",10,muted,false))
            card.addView(text("Timing stated by source: ${s.timing}",10,muted,false))
            if(s.url.isNotBlank())card.addView(button("Open source ↗",blue){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(s.url)))})
            val lp=LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);lp.bottomMargin=dp(9)
            list.addView(card,lp)
        }
    }

    private fun refreshFeeds(userInitiated:Boolean) {
        status.text="Checking ${FeedEngine.sources.size} public feeds…"
        executor.execute {
            val batch=FeedEngine.fetchAll()
            val apiBatch=PublicApiEngine.fetch(this)
            val fetched=batch.signals + apiBatch.signals
            val oldIds=signals.map{it.id}.toSet()
            val fresh=fetched.filter{it.id !in oldIds}
            val merged=(fetched+signals.filter{it.manual}).distinctBy{it.id}.sortedByDescending{it.date}.take(600)
            signals=merged.toMutableList();SignalStore.save(this,signals)
            SignalStore.saveRefreshSnapshot(this, fetched.size, fresh.size, batch.failed + apiBatch.failed)
            val notify=fresh.filter{it.official && it.score()>=7}
            notify.forEach{sendNotification(it)}
            runOnUiThread {
                status.text="Checked ${SimpleDateFormat("HH:mm",Locale.US).format(Date())} · ${fetched.size} items · ${fresh.size} new · ${batch.successful} RSS feeds OK · ${apiBatch.ok} APIs OK · ${batch.failed + apiBatch.failed} failed" +
                    if (batch.failedSources.isNotEmpty() || apiBatch.notes.isNotEmpty()) "\n${(batch.failedSources + apiBatch.notes).joinToString(" · ")}" else ""
                renderGlobalMap()
                renderFieldNotes()
                renderSignals()
                if(userInitiated)Toast.makeText(this,"Refresh complete: ${fresh.size} new records",Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showAddDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),0)}
        fun field(hint:String)=EditText(this).apply{setSingleLine(true);this.hint=hint;setTextColor(Color.WHITE);setHintTextColor(muted)}
        val title=field("Signal title *");val region=field("Country / region");val url=field("Source URL");val notes=EditText(this).apply{hint="Evidence summary and alternative explanation";setTextColor(Color.WHITE);setHintTextColor(muted);minLines=3}
        val cat=Spinner(this);cat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,Categories.all)
        val timing=Spinner(this);timing.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Not stated","Historical","Ongoing","Expected within 30 days","Expected within 7 days","Immediate official warning"))
        val reliability=field("Source reliability 1–5 (default 3)");val corroboration=field("Independent sources 1–5 (default 1)")
        box.addView(title);box.addView(cat);box.addView(region);box.addView(url);box.addView(notes);box.addView(text("Event timing explicitly stated by source",12,muted,false));box.addView(timing);box.addView(reliability);box.addView(corroboration)
        AlertDialog.Builder(this).setTitle("Add evidence record").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                if(title.text.isNullOrBlank()){Toast.makeText(this,"Title required",Toast.LENGTH_SHORT).show();return@setPositiveButton}
                val r=reliability.text.toString().toIntOrNull()?.coerceIn(1,5)?:3
                val c=corroboration.text.toString().toIntOrNull()?.coerceIn(1,5)?:1
                val u=url.text.toString().trim()
                val s=Signal(java.util.UUID.randomUUID().toString(),title.text.toString(),cat.selectedItem.toString(),region.text.toString(),"User-added source",u,notes.text.toString(),System.currentTimeMillis(),r,c,3,2,3,false,timing.selectedItem.toString(),true)
                signals.add(0,s);SignalStore.save(this,signals);renderGlobalMap();renderSignals()
            }.show()
    }

    private fun exportHistory(){
        val json=org.json.JSONArray();signals.forEach{json.put(it.toJson())}
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"watchtower-history.json")}
        exportJson=json.toString();startActivityForResult(intent,44)
    }
    private var exportJson=""
    @Deprecated("Legacy document picker callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==44&&resultCode==RESULT_OK){data?.data?.let{uri->contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(exportJson)}}}}

    private fun scheduleRefresh(){
        val scheduler=getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler
        val info=JobInfo.Builder(701,ComponentName(this,RefreshJobService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(6*60*60*1000L).setPersisted(false).build()
        scheduler.schedule(info)
    }
    private fun createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel("watchtower_alerts","Watchtower high-priority signals",NotificationManager.IMPORTANCE_DEFAULT).apply{description="New high-priority official public-source signals"})}}
    private fun requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),77)}
    private fun sendNotification(s:Signal){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val intent=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=if(Build.VERSION.SDK_INT>=26)android.app.Notification.Builder(this,"watchtower_alerts") else android.app.Notification.Builder(this)
        n.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("WATCHTOWER · ${s.score()}/10").setContentText(s.title).setContentIntent(intent).setAutoCancel(true)
        nm.notify(s.id.hashCode(),n.build())
    }
    private fun text(t:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply{text=t;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD);setPadding(0,dp(3),0,dp(3))}
    private fun statCard(label:String,value:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(8),dp(8));setBackgroundColor(panel);addView(text(label,9,muted,true));addView(text(value,23,Color.WHITE,true))}
    private fun button(label:String,color:Int,action:()->Unit)=Button(this).apply{text=label;setTextColor(if(color==green)Color.BLACK else Color.WHITE);setBackgroundTintList(android.content.res.ColorStateList.valueOf(if(color==blue)Color.rgb(43,91,132) else if(color==green)Color.rgb(84,214,160) else Color.rgb(43,56,70)));setOnClickListener{action()}}
    private fun space(h:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(h))}
    private fun spaceW(w:Int)=View(this).apply{layoutParams=LinearLayout.LayoutParams(dp(w),1)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun scoreColor(s:Int)=if(s>=9)Color.rgb(240,120,120) else if(s>=7)Color.rgb(243,189,96) else if(s>=4)Color.rgb(121,185,245) else green
    private fun date(t:Long)=SimpleDateFormat("MMM d, HH:mm",Locale.US).format(Date(t))
}
