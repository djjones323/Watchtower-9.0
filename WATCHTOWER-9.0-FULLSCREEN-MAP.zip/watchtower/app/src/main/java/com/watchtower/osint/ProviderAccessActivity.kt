package com.watchtower.osint

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Provider credentials are encrypted with an Android Keystore AES key.
 * This screen stores credentials only; provider adapters must be enabled separately.
 */
class ProviderAccessActivity : Activity() {
    private val bg = Color.rgb(16,21,27)
    private val panel = Color.rgb(26,34,44)
    private val muted = Color.rgb(154,168,183)
    private val blue = Color.rgb(121,185,245)
    private val green = Color.rgb(84,214,160)
    private lateinit var eia: EditText
    private lateinit var openskyUser: EditText
    private lateinit var openskyPass: EditText
    private lateinit var ais: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("WATCHTOWER", 25, Color.WHITE, true))
        root.addView(label("PROVIDER ACCESS", 13, blue, true))
        root.addView(label("Separate credential vault for data providers that require registration or sign-in.", 12, muted, false))
        root.addView(space(16))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(panel)
        }
        card.addView(label("EIA · ENERGY DATA", 14, Color.WHITE, true))
        card.addView(label("Free API key. Register with the U.S. Energy Information Administration.", 11, muted, false))
        eia = field("EIA API key")
        card.addView(eia)
        card.addView(linkButton("Get a free EIA key", "https://www.eia.gov/opendata/register.php"))
        card.addView(space(14))

        card.addView(label("OPENSKY · FLIGHT DATA", 14, Color.WHITE, true))
        card.addView(label("Account credentials for eligible OpenSky API access. Availability and rate limits depend on account eligibility.", 11, muted, false))
        openskyUser = field("OpenSky username")
        openskyPass = field("OpenSky password").apply { inputType = 129 }
        card.addView(openskyUser)
        card.addView(openskyPass)
        card.addView(linkButton("Open OpenSky account", "https://opensky-network.org/"))
        card.addView(space(14))

        card.addView(label("AISSTREAM · MARITIME DATA", 14, Color.WHITE, true))
        card.addView(label("API key for AISStream, if you register and accept its current usage terms.", 11, muted, false))
        ais = field("AISStream API key")
        card.addView(ais)
        card.addView(linkButton("Open AISStream", "https://aisstream.io/"))
        card.addView(space(14))

        root.addView(card)
        root.addView(space(14))

        root.addView(button("Save encrypted credentials", green) { saveCredentials() })
        root.addView(space(8))
        root.addView(button("Clear saved credentials", Color.rgb(255,145,125)) { confirmClear() })
        root.addView(space(14))
        root.addView(label("PRIVACY & STATUS", 12, blue, true))
        root.addView(label("Values are encrypted on this device using Android Keystore. They are not sent to WATCHTOWER servers. This screen does not itself connect providers or guarantee access. Provider adapters must be implemented and tested before saved credentials are used. Never enter your main email or banking password here.", 11, muted, false))
        root.addView(space(14))
        root.addView(button("← Back to globe", blue) { finish() })
        loadCredentials()
    }

    private fun loadCredentials() {
        eia.setText(SecureCredentialStore.get(this, "eia_key"))
        openskyUser.setText(SecureCredentialStore.get(this, "opensky_user"))
        openskyPass.setText(SecureCredentialStore.get(this, "opensky_pass"))
        ais.setText(SecureCredentialStore.get(this, "aisstream_key"))
    }

    private fun saveCredentials() {
        try {
            SecureCredentialStore.put(this, "eia_key", eia.text.toString().trim())
            SecureCredentialStore.put(this, "opensky_user", openskyUser.text.toString().trim())
            SecureCredentialStore.put(this, "opensky_pass", openskyPass.text.toString())
            SecureCredentialStore.put(this, "aisstream_key", ais.text.toString().trim())
            Toast.makeText(this, "Credentials saved encrypted on this device", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not encrypt credentials: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle("Clear provider credentials?")
            .setMessage("This removes the saved keys and account credentials from this device.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                SecureCredentialStore.clear(this)
                loadCredentials()
                Toast.makeText(this, "Saved credentials cleared", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setTextColor(Color.WHITE); setHintTextColor(muted)
        setSingleLine(true)
        textSize = 14f
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 7)
        }

    private fun space(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, h)
    }

    private fun button(title: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            text = title; setTextColor(Color.BLACK); setBackgroundColor(color)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

    private fun linkButton(title: String, url: String) =
        Button(this).apply {
            text = title; setTextColor(blue)
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }
}

object SecureCredentialStore {
    private const val PREFS = "watchtower_secure_credentials"
    private const val KEY_ALIAS = "watchtower_provider_aes"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    fun put(context: android.content.Context, name: String, value: String) {
        if (value.isEmpty()) {
            context.getSharedPreferences(PREFS, 0).edit().remove(name).apply()
            return
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        context.getSharedPreferences(PREFS, 0).edit()
            .putString(name, Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun get(context: android.content.Context, name: String): String {
        val packed = context.getSharedPreferences(PREFS, 0).getString(name, null) ?: return ""
        return try {
            val bytes = Base64.decode(packed, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val ciphertext = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun clear(context: android.content.Context) {
        context.getSharedPreferences(PREFS, 0).edit().clear().apply()
    }
}
